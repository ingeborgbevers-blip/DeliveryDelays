# Delivery performance and unresolved orders

**Title:** Delivery performance and unresolved orders

**Provenance:** Entirely synthetic dataset created for StraightLine Data & Training. All businesses, events and references are fictional.

**Period:** Orders created July–September 2026. Snapshot 30 September 2026.

**Grain:** OrderLines: one row per sales-order line. Deliveries: one row per shipment line. LineHistory: one row per recorded event.

**Relationships:** Customers 1:m OrderLines; Products 1:m OrderLines; OrderLines 1:m Deliveries and LineHistory. Use single-direction filtering in Power BI.

**Quantity check:** OrderedQty = sum(DeliveredQty) + CancelledQty + remaining quantity. No returns or over-deliveries are modelled.

**Value:** Ordered / outstanding values are quantity × UnitPriceGBP. Values are GBP excluding VAT.

**Initial headline:** Illustrative existing KPI: completed lines whose final delivery date is on/before CurrentPromiseDate ÷ all completed lines. This is line-level, not order-level OTIF.

**Alternative baseline:** Compare final delivery date with OriginalPromiseDate. Keep the population identical when comparing the two rates.

**Open backlog:** Remaining quantity > 0. Separate overdue commitments from commitments not yet due. State whether original or current promise is used.

**Partial deliveries:** A first shipment does not establish in-full completion. Aggregate Deliveries before joining quantities to OrderLines.

**Cancellations:** Cancelled lines and closed lines with cancelled balances are separate statuses. Do not silently treat them as completed in full.

**Time rules:** Dates have no time-of-day. Overdue at snapshot means promise date earlier than 30 September. On-time includes delivery on the promise date.

**Activity:** LastActivityDate includes automatic status events. Use history to distinguish delivery, human review and system updates.

**Week 1:** Build headline KPI; profile status, quantities, order value, open backlog and ageing.

**Week 2:** Investigate promise revisions, partial deliveries, cancellation treatment and meaningful inactivity. Propose definitions and exception handling.

**Four-week option:** Weeks 1–2: headline and exceptions. Week 3: history and definitions. Week 4: recommendations and user guidance.

**Inference limit:** Recorded reasons and associations do not prove causes. Proposed process and training changes have not been implemented or tested.

**Optional answer key:** CSV package includes a separate author key with benchmark counts. Keep it out of the public dataset if you want readers to investigate unaided.