# Optional author key — synthetic design benchmarks

Do not present these figures as real customer results.

{
  "Customers": 24,
  "Products": 18,
  "OrderLines": 803,
  "Deliveries": 784,
  "LineHistory": 2653
}

Completed lines: 561
On time against current promise: 532/561 (94.83%)
On time against original promise: 527/561 (93.94%)
Open lines: 159
Open lines overdue against original promise: 140

Investigate the difference in denominators, revised promises and partial closures. Blank agreement references are documentation gaps, not proof that changes were unapproved. No staff, carrier or warehouse effect has been independently established.
